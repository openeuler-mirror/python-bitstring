###########
Appendices
###########

Gathered together here are a few odds and ends that didn't fit well into either the user manual or the reference section. The only unifying theme is that none of them provide any vital knowledge about :mod:`bitstring`, and so they can all be safely ignored.

.. toctree:: 
   :maxdepth: 2
   
   examples
   exp-golomb
   optimisation
   release_notes
